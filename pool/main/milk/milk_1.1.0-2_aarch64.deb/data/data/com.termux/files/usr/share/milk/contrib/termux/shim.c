// Anchor the TLS segment at 64-byte alignment (bionic ARM64 requirement).
//
// Odin's code generator targets generic Linux and emits thread-locals with
// alignment 8, so the linker produces PT_TLS with p_align 8 and bionic
// refuses to load the binary ("TLS segment is underaligned"). A single
// 64-aligned thread-local here raises the whole TLS segment to 64 at link
// time, keeping every TP-relative relocation consistent (unlike patching the
// binary afterwards, which corrupts the linker's layout assumptions).
// Must be compiled with -fno-emulated-tls so this is real TLS, not emutls.
__thread char milk_tls_anchor[64] __attribute__((aligned(64)));

// Odin's core library assumes glibc on Linux (__errno_location), which
// bionic does not provide (it has __errno instead).
extern int *__errno(void);

int *__errno_location(void) {
	return __errno();
}

// 0 == PTHREAD_CANCEL_ENABLE / PTHREAD_CANCEL_DEFERRED
int pthread_setcancelstate(int state, int *oldstate) {
	(void)state;
	if (oldstate != 0) {
		*oldstate = 0;
	}
	return 0;
}

int pthread_setcanceltype(int type, int *oldtype) {
	(void)type;
	if (oldtype != 0) {
		*oldtype = 0;
	}
	return 0;
}

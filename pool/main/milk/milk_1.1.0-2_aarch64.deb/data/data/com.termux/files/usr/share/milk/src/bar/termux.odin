// Termux:API backends for the bar (Android has no sysfs readings, no
// NetworkManager, no brightnessctl: every /sys/class scan fails with
// Permission denied). Used automatically when the desktop tool is missing,
// so desktop Linux never takes these paths.
//
// Spawning a termux-* helper takes ~0.2-1 s: the 2 s status poll never runs
// them inline. Battery and network refresh through throttled jobs whose
// results are cached on the Bar (termux_bat / termux_net); brightness has no
// getter at all (termux-brightness is set-only), so the last applied value
// is tracked and shared with contrib/milk-keys through a state file.
package bar

import "core:encoding/json"
import "core:fmt"
import "core:hash"
import "core:os"
import "core:strconv"
import "core:strings"
import tx "../tx"

@(private) TERMUX_BATTERY_EVERY :: 30.0 // seconds between battery queries
@(private) TERMUX_NETWORK_EVERY :: 15.0 // seconds between network queries
@(private) TERMUX_CLIP_EVERY    :: 6.0 // seconds between Android clipboard polls

// Wi-Fi state plus mobile data (cellinfo): one job, two sections.
@(private)
TERMUX_NETWORK_SCRIPT :: `echo @@wifi; termux-wifi-connectioninfo 2>/dev/null
echo @@cell; termux-telephony-cellinfo 2>/dev/null`

// Last brightness applied through the Termux backend (0..255, -1 = unknown:
// termux-brightness cannot read the current value). Shared with
// contrib/milk-keys through $XDG_CACHE_HOME/milk/termux-brightness.
@(private)
termux_brightness_last := -1

// dBm to 0..100 (nmcli's scale): -30 or better is full, -90 or worse is gone.
@(private)
termux_rssi_percent :: proc(rssi: int) -> int {
	return clamp((rssi + 90) * 100 / 60, 0, 100)
}

// A JSON number that may arrive as integer, float or numeric string.
@(private)
termux_json_int :: proc(obj: json.Object, key: string) -> (int, bool) {
	switch v in obj[key] {
	case json.Integer:
		return int(v), true
	case json.Float:
		return int(v + 0.5), true
	case json.String:
		return strconv.parse_int(strings.trim_space(v), 10)
	case json.Null, json.Boolean, json.Array, json.Object:
		return 0, false
	}
	return 0, false
}

@(private)
termux_json_string :: proc(obj: json.Object, key: string) -> string {
	s, _ := obj[key].(json.String)
	return s
}

// ---------------------------------------------------------------------------
// Battery + network polling (called from poll_sources)
// ---------------------------------------------------------------------------

// Refresh the Termux caches whose throttle expired. The poll itself reads the
// caches, so the first round shows up to one throttle late.
@(private)
termux_poll :: proc(b: ^Bar, now: f64) {
	if b.tools.termux_battery && has_widget(b, .Battery) && !b.termux_bat_busy && now >= b.termux_bat_at {
		if start_job(b, .Termux_Battery, {"termux-battery-status"}, true, 10) != nil {
			b.termux_bat_busy = true
		}
		b.termux_bat_at = now + TERMUX_BATTERY_EVERY
	}
	if b.tools.termux_wifi && !b.termux_net_busy && now >= b.termux_net_at {
		if start_job(b, .Termux_Network, {"sh", "-c", TERMUX_NETWORK_SCRIPT}, true, 15) != nil {
			b.termux_net_busy = true
		}
		b.termux_net_at = now + TERMUX_NETWORK_EVERY
	}
	// Android → X clipboard: only with a learner wired (milk's clipboard) —
	// the learn path never pushes back, so our own pushes cannot loop.
	if b.tools.termux_clipboard && b.android_clip != nil && !b.termux_clip_busy && now >= b.termux_clip_at {
		if start_job(b, .Termux_Clip, {"termux-clipboard-get"}, true, 8) != nil {
			b.termux_clip_busy = true
		}
		b.termux_clip_at = now + TERMUX_CLIP_EVERY
	}
}

@(private)
termux_battery_done :: proc(b: ^Bar, output: string, ok: bool) {
	b.termux_bat_busy = false
	if !ok || len(strings.trim_space(output)) == 0 { return }
	value, err := json.parse_string(output, .JSON, false, context.temp_allocator)
	if err != .None { return }
	obj, is_obj := value.(json.Object)
	if !is_obj { return }
	present, _ := obj["present"].(json.Boolean)
	if present == false && obj["present"] != nil { return }
	percent, pok := termux_json_int(obj, "percentage")
	if !pok { percent, pok = termux_json_int(obj, "level") }
	if !pok { return }
	status := termux_json_string(obj, "status")
	st := Battery_State{
		present  = true,
		percent  = clamp(percent, 0, 100),
		charging = status == "CHARGING",
		full     = status == "FULL" || percent >= 100,
	}
	if st != b.termux_bat {
		b.termux_bat = st
		b.dirty = true
	}
}

@(private)
termux_clip_done :: proc(b: ^Bar, output: string, ok: bool) {
	b.termux_clip_busy = false
	if !ok { return }
	text := output
	// termux-clipboard-get prints the content plus a trailing newline.
	text = strings.trim_suffix(text, "\n")
	if len(text) == 0 { return }
	h := hash.fnv64a(transmute([]u8)text, 0xcbf29ce484222325)
	if h == b.termux_clip_last { return }
	b.termux_clip_last = h
	if b.android_clip != nil {
		b.android_clip(b.android_clip_data, strings.clone(text, context.temp_allocator))
	}
}

@(private)
termux_network_done :: proc(b: ^Bar, output: string, ok: bool) {
	b.termux_net_busy = false
	st: Network_State
	if ok {
		if wifi, wok := termux_parse_wifi(output); wok {
			st = wifi
		} else if mobile, mok := termux_parse_cell(output); mok {
			st = mobile
		}
	}
	if st != b.termux_net {
		b.termux_net = st
		b.dirty = true
	}
}

// termux-wifi-connectioninfo: connected (COMPLETED + SSID) means on.
@(private)
termux_parse_wifi :: proc(output: string) -> (Network_State, bool) {
	st: Network_State
	section := output_section(output, "wifi")
	if strings.trim_space(section) == "" { return st, false }
	value, err := json.parse_string(section, .JSON, false, context.temp_allocator)
	if err != .None { return st, false }
	obj, is_obj := value.(json.Object)
	if !is_obj { return st, false }
	ssid := termux_json_string(obj, "ssid")
	if ssid == "" || termux_json_string(obj, "supplicant_state") != "COMPLETED" { return st, false }
	st.kind = .Wifi
	st.quality = 100
	if rssi, rok := termux_json_int(obj, "rssi"); rok { st.quality = termux_rssi_percent(rssi) }
	return st, true
}

// termux-telephony-cellinfo: the registered entry's level (0..4) and type.
// Wi-Fi wins when both are up (parsed first).
@(private)
termux_parse_cell :: proc(output: string) -> (Network_State, bool) {
	st: Network_State
	section := output_section(output, "cell")
	if strings.trim_space(section) == "" { return st, false }
	value, err := json.parse_string(section, .JSON, false, context.temp_allocator)
	if err != .None { return st, false }
	arr, is_arr := value.(json.Array)
	if !is_arr { return st, false }
	for entry in arr {
		obj, is_obj := entry.(json.Object)
		if !is_obj { continue }
		if reg, _ := obj["registered"].(json.Boolean); !bool(reg) { continue }
		level, lok := termux_json_int(obj, "level")
		if !lok { level = 2 }
		st.kind = .Mobile
		st.quality = clamp(level, 0, 4) * 25
		return st, true
	}
	return st, false
}

// ---------------------------------------------------------------------------
// Brightness (set-only backend; see status.odin)
// ---------------------------------------------------------------------------

// Where milk-keys and the bar share the last applied Termux brightness.
@(private)
termux_brightness_file :: proc(allocator := context.temp_allocator) -> string {
	cache, found := os.lookup_env("XDG_CACHE_HOME", allocator)
	if !found || cache == "" {
		home := os.get_env("HOME", allocator)
		cache = strings.concatenate({home, "/.cache"}, allocator)
	}
	return strings.concatenate({cache, "/milk/termux-brightness"}, allocator)
}

// Remember a value both in memory and on disk (milk-keys reads the file).
@(private)
termux_brightness_remember :: proc(value: int) {
	termux_brightness_last = clamp(value, 0, 255)
	path := termux_brightness_file()
	if dir := path[:max(strings.last_index_byte(path, '/'), 0)]; dir != "" {
		tx.mkdir_all(dir)
	}
	_ = os.write_entire_file(path, transmute([]u8)fmt.tprintf("%d", termux_brightness_last))
}

// Best known brightness, for the widget before anything was set this boot.
@(private)
termux_brightness_recall :: proc() -> int {
	if termux_brightness_last >= 0 { return termux_brightness_last }
	if data, err := os.read_entire_file(termux_brightness_file(), context.temp_allocator); err == nil {
		if v, ok := strconv.parse_int(strings.trim_space(string(data)), 10); ok {
			termux_brightness_last = clamp(v, 0, 255)
			return termux_brightness_last
		}
	}
	// No getter exists: a middle guess until the first set (documented).
	return 128
}

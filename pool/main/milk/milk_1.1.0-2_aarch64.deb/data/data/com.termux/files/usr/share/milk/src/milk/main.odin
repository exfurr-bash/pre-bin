// MILK for Linux / X11.
//
// One binary, one event loop: the built-in dwm-inspired window manager
// (package wm), the workspace daemon (per-area wallpaper, shortcuts,
// indicator — package desktop) and the status bar (package bar) share a
// single X connection and are driven from here.
//
// Code lives in the clone; runtime data lives in <Documents>/milk/runtime
// (or --runtime-root / $MILK_RUNTIME), mirroring the Windows launchers.
package milk

import "core:c"
import "core:fmt"
import "core:log"
import "core:os"
import "core:path/filepath"
import "core:strconv"
import "core:strings"
import "core:sys/posix"
import "core:time"
import xlib "vendor:x11/xlib"

import bar "../bar"
import clip "../clip"
import config "../config"
import desktop "../desktop"
import nightlight "../nightlight"
import polkit "../polkit"
import lock "../lock"
import notify "../notify"
import oobe "../oobe"
import tx "../tx"
import wm "../wm"

VERSION  :: "1.1.0"

// filepath.join returns an allocator error too; milk never runs out of memory here.
join :: proc(elems: []string, allocator := context.temp_allocator) -> string {
	s, _ := filepath.join(elems, allocator)
	return s
}
PID_NAME :: "milk.pid"
LOG_NAME :: "milk.log"
LEGACY_PID_NAME :: "Temenos.pid"

Options :: struct {
	command:      string,
	value:        string,
	runtime_root: string,
	config_path:  string,
	new_config:   bool, // the configuration was just created from the defaults
	foreground:   bool,
	no_bar:       bool,
	no_wm:        bool,
	no_setup:     bool,
	verbose:      bool,
}

usage :: proc() {
	fmt.eprintln(`milk - per-workspace wallpapers, shortcuts, indicator and bar for X11

usage: milk [command] [options]

commands:
  start        run in the background, replacing a running instance   [default]
  restart      restart the running instance in place (windows stay open)
  stop         stop the running instance
  status       show whether milk is running and the active area
  reload       re-read milk.json in the running instance
  test         print diagnostics (active area, wallpaper, shortcuts, window manager)
  setup        run the setup wizard (theme, wallpapers, bar, keyboard) now
  settings     open the settings app (optionally on a section: wallpapers, windows, desktop...)
  switch N     ask the window manager to activate area N
  update       pull milk, Spoil and lactase, rebuild them and restart in place
               ("update check" only says whether there is something new)
  doctor       check the installation: programs, fonts, session, configuration
  lock         lock the screen (asks the running milk; locks by itself when none runs)
  version      print the version

options:
  --foreground, -f     stay attached to the terminal and log to stderr
  --no-bar             do not start the bar
  --no-wm              do not act as the window manager (use dwm/openbox instead)
  --no-setup           skip the first-run setup wizard
  --runtime-root DIR   runtime data directory (default: <Documents>/milk/runtime or $MILK_RUNTIME)
  --config FILE        configuration file (default: $MILK_CONFIG or ~/.config/milk/milk.json)
  --verbose, -v        debug logging`)
}

main :: proc() {
	opts, ok := parse_args(os.args[1:])
	if !ok {
		usage()
		os.exit(2)
	}
	if opts.runtime_root == "" { opts.runtime_root = default_runtime_root() }
	if opts.config_path == "" {
		opts.config_path = default_config_path()
		switch opts.command {
		case "start", "restart", "setup", "settings", "test":
			opts.new_config = create_default_config(opts.config_path)
		}
	}

	code := 0
	switch opts.command {
	case "start":            code = cmd_start(&opts)
	case "restart":          code = cmd_restart(&opts)
	case "update":           code = cmd_update(&opts)
	case "doctor":           code = cmd_doctor(&opts)
	case "stop":             code = cmd_stop(&opts)
	case "status":           code = cmd_status(&opts)
	case "reload":           code = cmd_reload(&opts)
	case "test":             code = cmd_test(&opts)
	case "switch":           code = cmd_switch(&opts)
	case "setup":            code = cmd_setup(&opts)
	case "settings":         code = cmd_settings(&opts)
	case "lock":             code = cmd_lock(&opts) // session.odin
	case "version":          fmt.println("milk", VERSION)
	case "help":             usage()
	case:
		fmt.eprintfln("unknown command: %s", opts.command)
		usage()
		code = 2
	}
	os.exit(code)
}

parse_args :: proc(args: []string) -> (opts: Options, ok: bool) {
	opts.command = "start"
	positional := 0
	i := 0
	for i < len(args) {
		a := args[i]
		switch a {
		case "--foreground", "-f": opts.foreground = true
		case "--no-bar":           opts.no_bar = true
		case "--no-wm":            opts.no_wm = true
		case "--no-setup":         opts.no_setup = true
		case "--verbose", "-v":    opts.verbose = true
		case "--help", "-h":       opts.command = "help"
		case "--runtime-root", "--config":
			if i + 1 >= len(args) {
				fmt.eprintfln("%s needs a value", a)
				return opts, false
			}
			i += 1
			if a == "--config" { opts.config_path = args[i] } else { opts.runtime_root = args[i] }
		case:
			if strings.has_prefix(a, "-") {
				fmt.eprintfln("unknown option: %s", a)
				return opts, false
			}
			switch positional {
			case 0: opts.command = a
			case 1: opts.value = a
			case:
				fmt.eprintfln("unexpected argument: %s", a)
				return opts, false
			}
			positional += 1
		}
		i += 1
	}
	return opts, true
}

// ---------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------
home_dir :: proc() -> string {
	if v, found := os.lookup_env("HOME", context.temp_allocator); found && v != "" { return v }
	return "/"
}

// XDG_<KEY>_DIR from ~/.config/user-dirs.dirs (e.g. "DOCUMENTS" -> ~/Documentos on this system).
xdg_user_dir :: proc(key: string, fallback: string) -> string {
	config_home, found := os.lookup_env("XDG_CONFIG_HOME", context.temp_allocator)
	if !found || config_home == "" { config_home = join({home_dir(), ".config"}) }
	path := join({config_home, "user-dirs.dirs"})
	data, err := os.read_entire_file(path, context.temp_allocator)
	if err != nil { return fallback }
	wanted := fmt.tprintf("XDG_%s_DIR=", key)
	text := string(data)
	for line in strings.split_lines_iterator(&text) {
		trimmed := strings.trim_space(line)
		if !strings.has_prefix(trimmed, wanted) { continue }
		value := strings.trim(trimmed[len(wanted):], "\"")
		value, _ = strings.replace_all(value, "$HOME", home_dir(), context.temp_allocator)
		if value != "" { return value }
	}
	return fallback
}

default_runtime_root :: proc() -> string {
	for name in ([]string{"MILK_RUNTIME", "TEMENOS_RUNTIME"}) {
		if env, found := os.lookup_env(name, context.temp_allocator); found && env != "" {
			return strings.clone(env)
		}
	}
	documents := xdg_user_dir("DOCUMENTS", join({home_dir(), "Documents"}))
	runtime := join({documents, "milk", "runtime"}, context.allocator)
	// Runtime data from before the rename keeps working until it is moved.
	legacy := join({documents, "Temenos", "runtime"})
	if !os.is_directory(runtime) && os.is_directory(legacy) {
		delete(runtime)
		return strings.clone(legacy)
	}
	return runtime
}

// The configuration lives outside the clone, so updating milk never touches it
// (and it is never committed): $MILK_CONFIG, else
// $XDG_CONFIG_HOME/milk/milk.json (~/.config/milk/milk.json).
default_config_path :: proc() -> string {
	if v, found := os.lookup_env("MILK_CONFIG", context.temp_allocator); found && v != "" { return strings.clone(v) }
	config_home, found := os.lookup_env("XDG_CONFIG_HOME", context.temp_allocator)
	if !found || config_home == "" {
		home, has_home := os.lookup_env("HOME", context.temp_allocator)
		config_home = join({has_home ? home : "/", ".config"}, context.temp_allocator)
	}
	// Kept for the whole run (reloads read it again): not the temp allocator.
	return join({config_home, "milk", "milk.json"}, context.allocator)
}

// milk.default.json, built into the binary: language from the system, the
// keyboard left as it is, no personal shortcuts.
DEFAULT_CONFIG :: #load("../../milk.default.json", string)

// Write the defaults when there is no configuration yet; true when it did
// (milk then shows the setup wizard, whatever the runtime marker says).
create_default_config :: proc(path: string) -> bool {
	if os.exists(path) { return false }
	dir := filepath.dir(path)
	if err := tx.mkdir_all(dir); err != nil && !os.is_directory(dir) {
		fmt.eprintfln("milk: cannot create %s: %v", dir, err)
		return false
	}
	if err := os.write_entire_file(path, DEFAULT_CONFIG); err != nil {
		fmt.eprintfln("milk: cannot write %s: %v", path, err)
		return false
	}
	return true
}

find_in_path :: proc(name: string) -> (string, bool) {
	path_env, found := os.lookup_env("PATH", context.temp_allocator)
	if !found { return "", false }
	for dir in strings.split(path_env, ":", context.temp_allocator) {
		candidate := join({dir, name})
		if os.is_file(candidate) { return candidate, true }
	}
	return "", false
}

// ---------------------------------------------------------------------------
// Single instance (PID file), like the Windows implementation
// ---------------------------------------------------------------------------
read_pid :: proc(pid_file: string) -> (int, bool) {
	data, err := os.read_entire_file(pid_file, context.temp_allocator)
	if err != nil { return 0, false }
	pid, ok := strconv.parse_int(strings.trim_space(string(data)), 10)
	return pid, ok && pid > 0
}

pid_alive :: proc(pid: int) -> bool {
	if posix.kill(posix.pid_t(pid), posix.Signal(0)) == .OK { return true }
	return posix.errno() == .EPERM
}

is_milk :: proc(pid: int) -> bool {
	data, err := os.read_entire_file(fmt.tprintf("/proc/%d/cmdline", pid), context.temp_allocator)
	if err != nil { return false }
	return strings.contains(string(data), "milk") || strings.contains(string(data), "temenos")
}

running_pid :: proc(pid_file: string) -> (int, bool) {
	pid, ok := read_pid(pid_file)
	if !ok || !pid_alive(pid) || !is_milk(pid) { return 0, false }
	return pid, true
}

// Terminate a previous instance (SIGTERM, then SIGKILL after 2 s).
stop_instance :: proc(pid_file: string) -> (stopped: bool) {
	pid, ok := running_pid(pid_file)
	if !ok || pid == os.get_pid() { return false }
	posix.kill(posix.pid_t(pid), .SIGTERM)
	for _ in 0 ..< 40 {
		time.sleep(50 * time.Millisecond)
		if !pid_alive(pid) { return true }
	}
	posix.kill(posix.pid_t(pid), .SIGKILL)
	time.sleep(200 * time.Millisecond)
	return true
}

write_pid :: proc(pid_file: string) -> bool {
	return os.write_entire_file(pid_file, fmt.tprintf("%d\n", os.get_pid())) == nil
}

remove_pid :: proc(pid_file: string) {
	if pid, ok := read_pid(pid_file); ok && pid == os.get_pid() {
		os.remove(pid_file)
	}
}

// ---------------------------------------------------------------------------
// Signals and daemonising
// ---------------------------------------------------------------------------
g_stop:    bool
g_reload:  bool
g_wake_fd: posix.FD = -1
g_pid_file: string

signal_handler :: proc "c" (sig: posix.Signal) {
	#partial switch sig {
	case .SIGTERM, .SIGINT: g_stop = true
	case .SIGHUP:           g_reload = true
	case .SIGUSR1:          g_restart = true; g_stop = true
	case .SIGUSR2:          g_lock = true // `milk lock` (session.odin)
	case:
	}
	if g_wake_fd >= 0 {
		b: [1]u8 = {1}
		posix.write(g_wake_fd, &b[0], 1)
	}
}

// Self-pipe so that poll() wakes up on signals; SIGCHLD is caught (no-op) so
// children stay reapable by the modules that spawned them.
install_signals :: proc() -> (wake_read: posix.FD, ok: bool) {
	fds: [2]posix.FD
	if posix.pipe(&fds) != .OK { return -1, false }
	for fd in fds {
		flags := posix.fcntl(fd, .GETFL)
		posix.fcntl(fd, .SETFL, flags | c.int(posix.O_NONBLOCK))
		posix.fcntl(fd, .SETFD, c.int(posix.FD_CLOEXEC)) // not inherited by a restart
	}
	g_wake_fd = fds[1]
	when TERMUX_BUILD {
		// Bionic: core:sys/posix's raw sigaction follows the glibc struct
		// layout and silently mis-installs (every disposition stays SIG_DFL,
		// so SIGHUP/SIGTERM kill instead of reloading/stopping). libc
		// signal() has no struct involved and works; an EINTR from the
		// missing SA_RESTART just shortens one poll sleep (the loop continues).
		for sig in ([]posix.Signal{.SIGTERM, .SIGINT, .SIGHUP, .SIGUSR1, .SIGUSR2, .SIGCHLD}) {
			posix.signal(sig, signal_handler)
		}
		posix.signal(.SIGPIPE, auto_cast posix.SIG_IGN)
	} else {
		act: posix.sigaction_t
		act.sa_handler = signal_handler
		posix.sigemptyset(&act.sa_mask)
		act.sa_flags = {.RESTART}
		for sig in ([]posix.Signal{.SIGTERM, .SIGINT, .SIGHUP, .SIGUSR1, .SIGUSR2, .SIGCHLD}) {
			posix.sigaction(sig, &act, nil)
		}
		ignore: posix.sigaction_t
		ignore.sa_handler = proc "c" (_: posix.Signal) {}
		posix.sigemptyset(&ignore.sa_mask)
		ignore.sa_flags = {.RESTART}
		posix.sigaction(.SIGPIPE, &ignore, nil)
	}
	return fds[0], true
}

daemonize :: proc(log_path: string) -> bool {
	pid := posix.fork()
	if pid < 0 { return false }
	if pid > 0 { posix._exit(0) }
	posix.setsid()
	pid = posix.fork()
	if pid < 0 { return false }
	if pid > 0 { posix._exit(0) }
	posix.chdir("/")
	null := posix.open("/dev/null", {})
	clog := strings.clone_to_cstring(log_path, context.temp_allocator)
	logfd := posix.open(clog, {.WRONLY, .CREAT, .TRUNC}, posix.mode_t{.IRUSR, .IWUSR, .IRGRP, .IROTH})
	if null >= 0 {
		posix.dup2(null, 0)
		posix.close(null)
	}
	if logfd >= 0 {
		posix.dup2(logfd, 1)
		posix.dup2(logfd, 2)
		posix.close(logfd)
	}
	return true
}

// Assigning context.logger only affects the current scope, so the caller sets it.
make_logger :: proc(opts: ^Options) -> log.Logger {
	level := opts.verbose ? log.Level.Debug : log.Level.Info
	options := opts.foreground ? log.Options{.Level, .Terminal_Color} : log.Options{.Level, .Date, .Time}
	return log.create_console_logger(level, options)
}

// ---------------------------------------------------------------------------
// start
// ---------------------------------------------------------------------------
cmd_start :: proc(opts: ^Options) -> int {
	cfg, err := config.load(opts.config_path)
	if err != "" {
		fmt.eprintfln("milk: %s", err)
		return 1
	}
	if display, found := os.lookup_env("DISPLAY", context.temp_allocator); !found || display == "" {
		fmt.eprintln("milk: DISPLAY is not set; start it from an X session (.xinitrc, openbox autostart).")
		return 1
	}
	if !os.is_directory(opts.runtime_root) {
		if mkerr := tx.mkdir_all(opts.runtime_root); mkerr != nil && mkerr != .Exist {
			fmt.eprintfln("milk: could not create %s: %v", opts.runtime_root, mkerr)
			return 1
		}
	}
	if !opts.foreground {
		if !daemonize(join({opts.runtime_root, LOG_NAME})) {
			fmt.eprintln("milk: could not fork into the background")
			return 1
		}
	}
	context.logger = make_logger(opts)
	code := run(opts, cfg)
	// SIGUSR1 (`milk restart`, `milk update`): everything was let go, start again in this process.
	if g_restart { restart_self() }
	return code
}

Runner :: struct {
	opts:    ^Options,
	cfg:     ^config.Config,
	c:       ^tx.Connection,
	manager: ^wm.Manager,
	daemon:  ^desktop.Daemon,
	bar:     ^bar.Bar,
	notes:   ^notify.Notifier,
	clips:   ^clip.Clipboard,
	night:   ^nightlight.Night_Light, // owner of the screen gamma: night light and nightlight.set_dim
	wake_fd: posix.FD,
	compositor_on:    bool,                // lactase was asked to run (compositor.enabled)
	idle:             ^lock.Manager,       // lock screen and idle stages (session.odin)
	session:          Session_Menu,        // the bar's power menu (session.odin)
	lactase_children: [dynamic]posix.pid_t, // lactase launchers not reaped yet
	apps:             App_Theme,           // GTK/Qt apps in milk's colours (apptheme.odin)
	agent:            ^polkit.Agent,       // the polkit authentication agent (nil: off)
}

// The strip the bar occupies on its monitor, which the window manager must keep free.
bar_reservation :: proc(cfg: ^config.Config, opts: ^Options) -> (monitor: string, top, bottom: i32) {
	if !cfg.bar.enabled || opts.no_bar { return cfg.bar.monitor, 0, 0 }
	size := i32(cfg.bar.height)
	if cfg.bar.style == "floating" { size += i32(cfg.bar.margin) }
	if cfg.bar.position == "bottom" { return cfg.bar.monitor, 0, size }
	return cfg.bar.monitor, size, 0
}

// setxkbmap from the keyboard section (empty fields keep the server's setting).
apply_keyboard :: proc(cfg: ^config.Config) {
	kb := &cfg.keyboard
	if kb.layout == "" && kb.variant == "" && kb.model == "" && kb.options == "" { return }
	argv := make([dynamic]string, context.temp_allocator)
	append(&argv, "setxkbmap")
	if kb.layout != ""  { append(&argv, "-layout", kb.layout) }
	if kb.variant != "" { append(&argv, "-variant", kb.variant) }
	if kb.model != ""   { append(&argv, "-model", kb.model) }
	if kb.options != "" { append(&argv, "-option", "", "-option", kb.options) }
	process, err := os.process_start({command = argv[:]})
	if err != nil {
		log.warnf("Could not run setxkbmap: %v", err)
		return
	}
	state, _ := os.process_wait(process, 5 * time.Second)
	if state.exit_code != 0 { log.warnf("setxkbmap exited with %d", state.exit_code) }
}

// Bar clicks on the bell and the clipboard open their panels.
bar_click :: proc(data: rawptr, id: string, anchor: tx.Rect) -> bool {
	r := (^Runner)(data)
	switch id {
	case "notifications":
		if r.notes == nil { return false }
		if r.clips != nil { clip.close_panel(r.clips) }
		if r.bar != nil { bar.close_popups(r.bar) }
		notify.toggle_panel(r.notes)
		return true
	case "clipboard":
		if r.clips == nil { return false }
		if r.notes != nil { notify.close_panel(r.notes) }
		if r.bar != nil { bar.close_popups(r.bar) }
		clip.toggle_panel(r.clips, anchor)
		return true
	case "session":
		return open_session_menu(r, anchor) // session.odin
	}
	return false
}

// Fresh Android clipboard content for the history (see
// bar.set_android_clipboard; package clip never pushes it back).
android_clip_learn :: proc(data: rawptr, text: string) {
	clip.clipboard_learn_android((^clip.Clipboard)(data), text)
}

// Desktop icons and windows dragged onto the bar's area dots go to that area.
// The dragging component holds the pointer grab (the bar sees no motion), so
// it reports the pointer here: the dot under it is highlighted and its area
// (1-based, 0 = none) returned; `ending` clears the highlight (the drop, or
// x = y = -1 for a cancelled drag). No bar: nothing is a drop target.
drop_probe :: proc(data: rawptr, x, y: i32, ending: bool) -> int {
	r := (^Runner)(data)
	if r.bar == nil { return 0 }
	n := bar.area_at(r.bar, x, y)
	bar.set_drop_target(r.bar, ending ? 0 : n, !ending)
	return n
}

create_bar :: proc(r: ^Runner) {
	b, ok := bar.create(r.c, r.cfg)
	if !ok {
		log.warn("The bar could not be created; continuing without it")
		return
	}
	r.bar = b
	bar.set_config_path(b, r.opts.config_path)
	bar.set_click_handler(b, bar_click, r)
}

run :: proc(opts: ^Options, cfg: ^config.Config) -> int {
	// Everything milk starts (the settings app from the gear card, helper
	// scripts) finds this instance's runtime folder, pid file included.
	os.set_env("MILK_RUNTIME", opts.runtime_root)
	// Restarted in place: the applications the previous image started are ours to reap.
	if v, found := os.lookup_env("MILK_RESTARTED", context.temp_allocator); found && v != "" {
		os.unset_env("MILK_RESTARTED")
		adopt_children()
	}
	// Spoil, lactase and the settings app read the same milk.json.
	if abs, ok := filepath.abs(opts.config_path, context.temp_allocator); ok == nil { os.set_env("MILK_CONFIG", abs) }
	pid_file := join({opts.runtime_root, PID_NAME}, context.allocator)
	g_pid_file = pid_file
	if stop_instance(pid_file) { log.info("Replaced the previous milk instance") }
	// An instance started before the rename to milk records itself as Temenos.pid.
	if stop_instance(join({opts.runtime_root, LEGACY_PID_NAME})) { log.info("Replaced the running Temenos instance") }
	if !write_pid(pid_file) { log.warnf("Could not write %s", pid_file) }
	defer remove_pid(pid_file)

	c, connected := tx.connect()
	if !connected {
		log.error("Could not open the X display")
		return 1
	}
	tx.io_error_cleanup = proc() { remove_pid(g_pid_file) }
	defer tx.disconnect(c)

	cfg := cfg
	apply_keyboard(cfg)
	// First run: the setup wizard (theme, wallpapers, bar, keyboard) comes
	// before the window manager; its choices are read back from milk.json.
	if !opts.no_setup && (opts.new_config || oobe.needed(opts.runtime_root, opts.config_path)) {
		log.info("First run: starting the setup wizard")
		oobe.app_version = VERSION
		if oobe.run(c, opts.config_path, opts.runtime_root) {
			if fresh, err := config.load(opts.config_path); err == "" {
				config.destroy(cfg)
				cfg = fresh
				apply_keyboard(cfg)
			} else {
				log.errorf("The setup wizard wrote an invalid configuration (%s); keeping the previous one", err)
			}
		}
	}

	write_rofi_theme(cfg)
	r := Runner{opts = opts, cfg = cfg, c = c}
	apptheme_apply(&r) // GTK and Qt apps follow the theme (apptheme.odin)
	defer apptheme_stop(&r)
	mask := desktop.ROOT_EVENT_MASK
	if cfg.bar.enabled && !opts.no_bar { mask |= bar.ROOT_EVENT_MASK }
	if cfg.wm.enabled && !opts.no_wm { mask |= wm.ROOT_EVENT_MASK }
	xlib.SelectInput(c.dpy, c.root, mask)

	// The window manager comes first: the bar and the desktop layer read the
	// EWMH properties it publishes.
	if cfg.wm.enabled && !opts.no_wm {
		if m, wok := wm.create(c, cfg); wok {
			r.manager = m
			wm.set_drop_probe(m, drop_probe, &r) // windows dropped on the area dots
			monitor, top, bottom := bar_reservation(cfg, opts)
			wm.set_reserved(m, monitor, top, bottom)
			wm.start(m)
		} else {
			log.warn("Another window manager is running; the built-in one stays off (use --no-wm or wm.enabled=false to silence this)")
			fallback := desktop.ROOT_EVENT_MASK
			if cfg.bar.enabled && !opts.no_bar { fallback |= bar.ROOT_EVENT_MASK }
			xlib.SelectInput(c.dpy, c.root, fallback)
		}
	}
	defer if r.manager != nil { wm.destroy(r.manager) }

	daemon, dok := desktop.create(c, cfg, opts.runtime_root)
	if !dok {
		log.error("Could not initialise the desktop daemon")
		return 1
	}
	r.daemon = daemon
	defer desktop.destroy(daemon)
	desktop.set_drop_probe(daemon, drop_probe, &r) // icons dropped on the area dots

	if cfg.bar.enabled && !opts.no_bar { create_bar(&r) }
	// r.bar = nil: the desktop, destroyed after it, may still end a drag (drop_probe).
	defer if r.bar != nil { bar.destroy(r.bar); r.bar = nil }

	if cfg.notifications.enabled {
		if n, nok := notify.create(c, cfg); nok { r.notes = n }
	}
	defer if r.notes != nil { notify.destroy(r.notes) }
	if cfg.clipboard.enabled {
		if cb, cok := clip.create(c, cfg, opts.runtime_root); cok { r.clips = cb }
	}
	defer if r.clips != nil { clip.destroy(r.clips) }
	// Android → X clipboard: the bar polls termux-clipboard-get and hands
	// fresh content to the clipboard history (which never pushes it back).
	if r.bar != nil && r.clips != nil {
		bar.set_android_clipboard(r.bar, android_clip_learn, r.clips)
	}
	// The gamma ramps (night light, dimming); destroyed before the X
	// connection closes, which puts the original ramps back.
	r.night = nightlight.create(c, cfg)
	// Restarting in place keeps the screen as it is; the new image takes over the ramps.
	defer nightlight.destroy(r.night, g_restart)
	session_start(&r)
	defer session_stop(&r)
	// Programs that need a password (pkexec, GParted...) ask polkit, which asks this agent.
	r.agent = polkit.create(c, cfg)
	defer polkit.destroy(r.agent)

	wake_read, sig_ok := install_signals()
	if !sig_ok {
		log.error("Could not install signal handlers")
		return 1
	}
	r.wake_fd = wake_read

	wm_label := tx.wm_name(c)
	if r.manager != nil { wm_label = "built-in" }
	log.infof("milk %s started (pid %d, wm %s, runtime %s)", VERSION, os.get_pid(), wm_label == "" ? "unknown" : wm_label, opts.runtime_root)
	// The bar first: the desktop layer and the area toast keep clear of it.
	if r.bar != nil { bar.start(r.bar) }
	desktop.start(daemon)
	if r.notes != nil { notify.start(r.notes) }
	if r.clips != nil { clip.start(r.clips) }
	compositor_sync(&r)
	defer delete(r.lactase_children)
	loop(&r)
	log.info("milk stopped")
	return 0
}

loop :: proc(r: ^Runner) {
	conn := r.c
	for !g_stop {
		for tx.pending(conn) > 0 {
			ev: xlib.XEvent
			tx.next_event(conn, &ev)
			// Dead keys typed into milk's text fields (the Wi-Fi password)
			// are consumed by the input method and come back composed.
			if tx.input_filter(&ev) { continue }
			if apptheme_event(r, &ev) { continue } // the XSETTINGS window
			if session_event(r, &ev) { continue }
			// The password dialog holds the keyboard: its keys never reach the shortcuts.
			if polkit.handle_event(r.agent, &ev) { continue }
			if r.manager != nil { wm.handle_event(r.manager, &ev) }
			desktop.handle_event(r.daemon, &ev)
			if r.bar != nil { bar.handle_event(r.bar, &ev) }
			if r.notes != nil { notify.handle_event(r.notes, &ev) }
			if r.clips != nil { clip.handle_event(r.clips, &ev) }
			if r.night != nil { nightlight.handle_event(r.night, &ev) }
			if g_stop { break }
		}
		if r.manager != nil {
			if wm.quit_requested(r.manager) { g_stop = true }
			if wm.reload_requested(r.manager) { g_reload = true }
			switch wm.panel_requested(r.manager) {
			case "clipboard":
				if r.clips != nil {
					if r.notes != nil { notify.close_panel(r.notes) }
					if r.bar != nil { bar.close_popups(r.bar) }
					clip.open_panel_centered(r.clips)
				}
			case "notifications":
				if r.notes != nil {
					if r.clips != nil { clip.close_panel(r.clips) }
					if r.bar != nil { bar.close_popups(r.bar) }
					notify.toggle_panel(r.notes)
				}
			case "lock":
				lock.lock_now(r.idle, "lock action")
			}
			// The root menu's entries for the desktop icons.
			if req := wm.desktop_requested(r.manager); req != "" { desktop.request(r.daemon, req) }
			// Night light and media keys (volume/brightness with the pop-up).
			for req in wm.system_requested(r.manager) { system_request(r, req) }
		}
		if r.bar != nil && bar.reload_requested(r.bar) { g_reload = true }
		if g_reload {
			g_reload = false
			reload(r)
		}
		if desktop.theme_changed(r.daemon) { reload_theme(r) }
		now := tx.now()
		compositor_reap(r)
		reap_adopted()
		apptheme_reap(r)
		if r.manager != nil { wm.tick(r.manager, now) }
		desktop.tick(r.daemon, now)
		if r.bar != nil { bar.tick(r.bar, now) }
		if r.notes != nil { notify.tick(r.notes, now) }
		if r.clips != nil { clip.tick(r.clips, now) }
		if r.night != nil { nightlight.tick(r.night, now) }
		session_tick(r)
		lock.tick(r.idle, now)
		polkit.tick(r.agent, now)
		if r.bar != nil && r.notes != nil { bar.set_badge(r.bar, "notifications", notify.unread_count(r.notes)) }

		timeout := desktop.next_timeout(r.daemon, now)
		if r.bar != nil {
			bt := bar.next_timeout(r.bar, now)
			if bt >= 0 && (timeout < 0 || bt < timeout) { timeout = bt }
		}
		if r.manager != nil {
			wt := wm.next_timeout(r.manager, now)
			if wt >= 0 && (timeout < 0 || wt < timeout) { timeout = wt }
		}
		if r.notes != nil {
			nt := notify.next_timeout(r.notes, now)
			if nt >= 0 && (timeout < 0 || nt < timeout) { timeout = nt }
		}
		if r.clips != nil {
			ct := clip.next_timeout(r.clips, now)
			if ct >= 0 && (timeout < 0 || ct < timeout) { timeout = ct }
		}
		if r.night != nil {
			lt := nightlight.next_timeout(r.night, now)
			if lt >= 0 && (timeout < 0 || lt < timeout) { timeout = lt }
		}
		if lt := lock.next_timeout(r.idle, now); lt >= 0 && (timeout < 0 || lt < timeout) { timeout = lt }
		if pt := polkit.next_timeout(r.agent, now); pt >= 0 && (timeout < 0 || pt < timeout) { timeout = pt }

		// Everything allocated from the temp allocator during this iteration is
		// released here; the poll set is built afterwards so it stays valid.
		free_all(context.temp_allocator)
		fds := make([dynamic]posix.pollfd, context.temp_allocator)
		append(&fds, posix.pollfd{fd = posix.FD(conn.fd), events = {.IN}})
		append(&fds, posix.pollfd{fd = r.wake_fd, events = {.IN}})
		bar_fds := 0
		if r.bar != nil {
			for fd in bar.poll_fds(r.bar) { append(&fds, posix.pollfd{fd = posix.FD(fd), events = {.IN}}) }
			bar_fds = len(fds) - 2
		}
		for fd in desktop.poll_fds(r.daemon) { append(&fds, posix.pollfd{fd = posix.FD(fd), events = {.IN}}) }
		desktop_fds := len(fds) - 2 - bar_fds
		notes_fds := 0
		if r.notes != nil {
			for fd in notify.poll_fds(r.notes) { append(&fds, posix.pollfd{fd = posix.FD(fd), events = {.IN}}) }
			notes_fds = len(fds) - 2 - bar_fds - desktop_fds
		}
		lock_fds := len(fds)
		for fd in lock.poll_fds(r.idle) { append(&fds, posix.pollfd{fd = posix.FD(fd), events = {.IN}}) }
		lock_fds = len(fds) - lock_fds
		for fd in polkit.poll_fds(r.agent) { append(&fds, posix.pollfd{fd = posix.FD(fd), events = {.IN}}) }
		if tx.pending(conn) > 0 { continue }

		timeout_ms: c.int = -1
		if timeout >= 0 { timeout_ms = c.int(timeout * 1000) + 1 }
		n := posix.poll(raw_data(fds), posix.nfds_t(len(fds)), timeout_ms)
		if n <= 0 { continue }
		if fds[1].revents != {} {
			buf: [64]u8
			for posix.read(r.wake_fd, &buf[0], len(buf)) > 0 {}
		}
		for pf, i in fds[2:] {
			if pf.revents == {} { continue }
			if i < bar_fds {
				if r.bar != nil { bar.handle_fd(r.bar, i32(pf.fd)) }
			} else if i < bar_fds + desktop_fds {
				desktop.handle_fd(r.daemon, i32(pf.fd))
			} else if i < bar_fds + desktop_fds + notes_fds {
				if r.notes != nil { notify.handle_fd(r.notes, i32(pf.fd)) }
			} else if i < bar_fds + desktop_fds + notes_fds + lock_fds {
				lock.handle_fd(r.idle, i32(pf.fd))
			} else {
				polkit.handle_fd(r.agent, i32(pf.fd))
			}
		}
	}
}

reload :: proc(r: ^Runner) {
	cfg, err := config.load(r.opts.config_path)
	if err != "" {
		log.errorf("Reload failed, keeping the previous configuration: %s", err)
		return
	}
	old := r.cfg
	r.cfg = cfg
	if r.manager != nil {
		monitor, top, bottom := bar_reservation(cfg, r.opts)
		wm.set_reserved(r.manager, monitor, top, bottom)
		wm.reload(r.manager, cfg)
	}
	desktop.reload(r.daemon, cfg)
	want_bar := cfg.bar.enabled && !r.opts.no_bar
	if r.bar != nil && !want_bar {
		bar.destroy(r.bar)
		r.bar = nil
	} else if r.bar != nil {
		bar.reload(r.bar, cfg)
	} else if want_bar {
		create_bar(r)
		if r.bar != nil { bar.start(r.bar) }
	}
	if r.notes != nil { notify.reload(r.notes, cfg) }
	if r.clips != nil { clip.reload(r.clips, cfg) }
	if r.night != nil { nightlight.reload(r.night, cfg) }
	lock.reload(r.idle, cfg)
	polkit.reload(r.agent, cfg)
	wakelock_sync(old, cfg)
	apply_keyboard(cfg)
	write_rofi_theme(cfg)
	apptheme_apply(r)
	oobe.refresh_wallpaper_theme_files(cfg)
	compositor_sync(r)
	config.destroy(old)
	log.info("Configuration reloaded")
}

// A window manager action for the main loop: the night light switch, or a
// media key that the bar performs and shows in its pop-up (without a bar,
// contrib/milk-keys does it as before).
system_request :: proc(r: ^Runner, action: string) {
	switch action {
	case "night-light":
		if r.night != nil && nightlight.toggle(r.night, r.opts.config_path) { g_reload = true }
	case "volume-up", "volume-down", "mute", "brightness-up", "brightness-down":
		if r.bar == nil || !bar.media_key(r.bar, action) { wm.run_keys_helper(r.manager, action) }
	}
}

// The wallpaper theme published new colours (a moment after the area or its
// wallpaper changed): everything takes them without applying the area again.
reload_theme :: proc(r: ^Runner) {
	cfg, err := config.load(r.opts.config_path)
	if err != "" {
		log.errorf("Could not apply the wallpaper colours: %s", err)
		return
	}
	old := r.cfg
	r.cfg = cfg
	if r.manager != nil { wm.reload(r.manager, cfg) }
	desktop.retheme(r.daemon, cfg)
	if r.bar != nil { bar.retheme(r.bar, cfg) }
	if r.notes != nil { notify.retheme(r.notes, cfg) }
	if r.clips != nil { clip.reload(r.clips, cfg) }
	lock.reload(r.idle, cfg)
	polkit.reload(r.agent, cfg)
	write_rofi_theme(cfg)
	apptheme_apply(r)
	oobe.refresh_wallpaper_theme_files(cfg)
	config.destroy(old)
	log.info("Wallpaper colours applied")
}

// ---------------------------------------------------------------------------
// stop / status / reload / switch / test
// ---------------------------------------------------------------------------
cmd_stop :: proc(opts: ^Options) -> int {
	pid_file := join({opts.runtime_root, PID_NAME})
	if stop_instance(pid_file) || stop_instance(join({opts.runtime_root, LEGACY_PID_NAME})) {
		fmt.println("milk stopped")
		return 0
	}
	fmt.println("milk is not running")
	return 1
}

cmd_reload :: proc(opts: ^Options) -> int {
	pid_file := join({opts.runtime_root, PID_NAME})
	pid, ok := running_pid(pid_file)
	if !ok {
		fmt.println("milk is not running")
		return 1
	}
	posix.kill(posix.pid_t(pid), .SIGHUP)
	fmt.printfln("Reload requested (pid %d)", pid)
	return 0
}

cmd_status :: proc(opts: ^Options) -> int {
	pid_file := join({opts.runtime_root, PID_NAME})
	pid, ok := running_pid(pid_file)
	if !ok {
		fmt.println("milk is not running")
		return 1
	}
	fmt.printfln("milk is running (pid %d)", pid)
	if c, connected := tx.connect(); connected {
		defer tx.disconnect(c)
		if index, has := desktop.current_desktop_index(c); has {
			fmt.printfln("Current area: %d of %d", index, desktop.desktop_count(c))
		}
	}
	return 0
}

cmd_switch :: proc(opts: ^Options) -> int {
	n, ok := strconv.parse_int(opts.value, 10)
	if !ok || n < 1 {
		fmt.eprintln("usage: milk switch N   (N >= 1)")
		return 2
	}
	c, connected := tx.connect()
	if !connected {
		fmt.eprintln("Could not open the X display")
		return 1
	}
	defer tx.disconnect(c)
	tx.send_client_message(c, "_NET_CURRENT_DESKTOP", {n - 1, 0, 0, 0, 0})
	tx.sync(c)
	fmt.printfln("Requested area %d (EWMH _NET_CURRENT_DESKTOP; dwm ignores this message, use its tag keys)", n)
	return 0
}

// The settings app: a normal window (the window manager floats it) that saves
// milk.json and signals the running instance itself.
cmd_settings :: proc(opts: ^Options) -> int {
	c, connected := tx.connect()
	if !connected {
		fmt.eprintln("Could not open the X display")
		return 1
	}
	defer tx.disconnect(c)
	context.logger = make_logger(opts)
	if !os.is_directory(opts.runtime_root) { tx.mkdir_all(opts.runtime_root) }
	oobe.app_version = VERSION
	oobe.run_settings(c, opts.config_path, opts.runtime_root, opts.value)
	return 0
}

// Run the setup wizard on demand, then ask a running instance to reload.
cmd_setup :: proc(opts: ^Options) -> int {
	c, connected := tx.connect()
	if !connected {
		fmt.eprintln("Could not open the X display")
		return 1
	}
	defer tx.disconnect(c)
	context.logger = make_logger(opts)
	if !os.is_directory(opts.runtime_root) { tx.mkdir_all(opts.runtime_root) }
	oobe.app_version = VERSION
	if !oobe.run(c, opts.config_path, opts.runtime_root) { return 1 }
	pid_file := join({opts.runtime_root, PID_NAME})
	if pid, ok := running_pid(pid_file); ok { posix.kill(posix.pid_t(pid), .SIGHUP) }
	return 0
}

// The Linux counterpart of `Temenos.ps1 -Test` in the Windows version.
cmd_test :: proc(opts: ^Options) -> int {
	fmt.println("milk", VERSION)
	cfg, err := config.load(opts.config_path)
	if err != "" {
		fmt.printfln("Config: %s -- ERROR: %s", opts.config_path, err)
	} else {
		fmt.printfln("Config: %s (%d areas, bar %s, built-in wm %s)", opts.config_path, len(cfg.workspaces),
		             cfg.bar.enabled ? "enabled" : "disabled", cfg.wm.enabled ? "enabled" : "disabled")
	}
	fmt.printfln("Runtime: %s", opts.runtime_root)
	pid_file := join({opts.runtime_root, PID_NAME})
	if pid, running := running_pid(pid_file); running {
		fmt.printfln("Daemon: running (pid %d)", pid)
	} else {
		fmt.println("Daemon: not running")
	}
	if feh, found := find_in_path("feh"); found { fmt.printfln("feh: %s", feh) } else { fmt.println("feh: NOT FOUND (wallpapers cannot be applied)") }

	c, connected := tx.connect()
	if !connected {
		fmt.println("X display: unavailable (DISPLAY not set or server unreachable)")
		return 1
	}
	defer tx.disconnect(c)
	wm := tx.wm_name(c)
	fmt.printfln("Window manager: %s", wm == "" ? "unknown (no _NET_SUPPORTING_WM_CHECK)" : wm)
	index, has_index := desktop.current_desktop_index(c)
	if has_index {
		fmt.printfln("Current area: %d", index)
	} else {
		fmt.println("Current area: unknown (_NET_CURRENT_DESKTOP is not published; dwm needs the ewmhtags patch)")
	}
	fmt.printfln("Total areas: %d", desktop.desktop_count(c))
	mon := tx.monitor_rect(c)
	fmt.printfln("Primary monitor: %dx%d at %d,%d", mon.w, mon.h, mon.x, mon.y)
	if cfg != nil && has_index {
		if source, found := desktop.wallpaper_source(cfg, opts.runtime_root, index); found {
			fmt.printfln("Wallpaper: %s", source)
		} else {
			fmt.println("Wallpaper: none configured")
		}
		common := join({opts.runtime_root, cfg.paths.common})
		if ws, known := config.workspace(cfg, index); known {
			area := join({opts.runtime_root, ws.folder})
			fmt.printfln("Shortcuts: %d common, %d in %s", desktop.shortcut_count(common), desktop.shortcut_count(area), ws.folder)
		} else {
			fmt.printfln("Shortcuts: %d common (area %d is not in milk.json)", desktop.shortcut_count(common), index)
		}
	}
	return 0
}

// Android mirror for notifications (Termux:API): every new popup is also
// posted to the Android shade through termux-notification, so phone apps'
// notifications stay visible when the X session is in the background.
// Opt-in (notifications.mirrorAndroid, off by default): edits reuse one
// Android notification per milk id (--id + --alert-once), nothing round-trips
// actions back, and nothing mirrors while the screen is locked (paused).
package notify

import "core:fmt"
import "core:log"
import "core:os"
import "core:strings"
import "core:sys/posix"

// Post `notif` to Android. Call only for new popups (not refreshes).
@(private)
mirror_android :: proc(n: ^Notifier, notif: ^Notification) {
	if !n.termux_mirror || n.paused { return }
	title := strings.trim_space(notif.summary)
	if title == "" { title = strings.trim_space(notif.app_name) }
	if title == "" { title = "milk" }
	body := strings.trim_space(notif.body)
	argv := make([dynamic]string, context.temp_allocator)
	append(&argv, "termux-notification", "--id", fmt.tprintf("milk-%d", notif.id), "--alert-once")
	if notif.urgency >= 2 { append(&argv, "--priority", "high") }
	append(&argv, "-t", title)
	if body != "" { append(&argv, "-c", body) }
	p, err := os.process_start(os.Process_Desc{command = argv[:]})
	if err != nil {
		log.debugf("Notifications: could not start termux-notification: %v", err)
		return
	}
	if p.handle != 0 && p.handle != ~uintptr(0) { posix.close(posix.FD(p.handle)) }
	append(&n.mirrors, posix.pid_t(p.pid))
}

// Reap finished mirror helpers.
@(private)
termux_reap_mirrors :: proc(n: ^Notifier, blocking: bool) {
	for i := len(n.mirrors) - 1; i >= 0; i -= 1 {
		status: i32
		flags: posix.Wait_Flags
		if !blocking { flags = {.NOHANG} }
		r := posix.waitpid(n.mirrors[i], &status, flags)
		if r == n.mirrors[i] || (r < 0 && posix.errno() != .EINTR) || blocking {
			unordered_remove(&n.mirrors, i)
		}
	}
}

// Whether `name` is an executable on $PATH.
@(private)
termux_tool_present :: proc(name: string) -> bool {
	path := os.get_env("PATH", context.temp_allocator)
	if path == "" { return false }
	for dir in strings.split(path, ":", context.temp_allocator) {
		if dir == "" { continue }
		full := strings.concatenate({dir, "/", name}, context.temp_allocator)
		if posix.access(strings.clone_to_cstring(full, context.temp_allocator), {.X_OK}) == .OK && os.is_file(full) {
			return true
		}
	}
	return false
}

// Recursive directory creation that also works on Android.
//
// os.make_directory_all is unusable there: Odin's Linux implementation walks
// down from an explicitly opened "/" (raw open syscall), which SELinux
// denies to apps (Permission_Denied) even though every component is
// traversable by path. A single os.make_directory (raw mkdir with the full
// path, resolved by the kernel) works fine, so this recreates the recursion
// component by component: existing prefixes are skipped with os.exists,
// missing ones created one level at a time.
//
// Returns nil when the directory exists afterwards (created or not), an
// os.Error otherwise. Use it instead of os.make_directory_all everywhere.
package tx

import "core:os"
import "core:strings"

// Create `path` and every missing parent. `perm` applies to created
// directories (parents milk creates are not expected to need custom modes;
// call sites that pass one keep passing it).
mkdir_all :: proc(path: string, perm := os.Permissions_Default_Directory) -> os.Error {
	cleaned := clean_path(path)
	if cleaned == "" || cleaned == "." || cleaned == ".." || strings.has_prefix(cleaned, "../") {
		return .Invalid_Path
	}
	return mkdir_all_clean(cleaned, perm)
}

// Lexically resolve "." and ".." (no filesystem access, so symlinks are not
// followed — exactly what directory creation needs).
@(private)
clean_path :: proc(path: string, allocator := context.temp_allocator) -> string {
	absolute := strings.has_prefix(strings.trim_space(path), "/")
	parts := strings.split(path, "/", allocator)
	out := make([dynamic]string, allocator)
	for part in parts {
		switch part {
		case "", ".":
			continue
		case "..":
			if len(out) > 0 && out[len(out) - 1] != ".." {
				pop(&out)
			} else if !absolute {
				append(&out, "..")
			}
		case:
			append(&out, part)
		}
	}
	joined := strings.join(out[:], "/", allocator)
	if absolute { return strings.concatenate({"/", joined}, allocator) }
	if joined == "" { return "." }
	return joined
}

@(private)
mkdir_all_clean :: proc(path: string, perm: os.Permissions) -> os.Error {
	// Split into prefixes without ever opening "/" itself.
	parts := strings.split(path, "/", context.temp_allocator)
	prefix := strings.builder_make(context.temp_allocator)
	absolute := strings.has_prefix(path, "/")
	if absolute { strings.write_byte(&prefix, '/') }
	for part in parts {
		if part == "" || part == "." { continue }
		if strings.builder_len(prefix) > 1 || (!absolute && strings.builder_len(prefix) > 0) {
			strings.write_byte(&prefix, '/')
		}
		strings.write_string(&prefix, part)
		current := strings.to_string(prefix)
		// Probes (is_directory/exists) can lie about system prefixes on
		// Android, so a mkdir .Exist always means "move on": either the
		// prefix is really there or the final check below rejects it.
		if os.is_directory(current) { continue }
		if err := os.make_directory(current, perm); err != nil && err != .Exist {
			if os.is_directory(current) { continue }
			return err
		}
	}
	if !os.is_directory(path) { return .Invalid_Path }
	return nil
}

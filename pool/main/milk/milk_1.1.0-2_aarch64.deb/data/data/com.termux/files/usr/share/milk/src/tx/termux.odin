// Termux (Android) detection at runtime, shared by milk, Spoil and lactase.
//
// Compile-time flags cannot cover everything (and Spoil/lactase take no
// flags at all): any backend choice that does not change linking — signal
// installation, helper commands, path fallbacks — keys off this instead.
package tx

import "core:os"
import "core:strings"

// Running inside Termux (as opposed to desktop Linux).
on_termux :: proc() -> bool {
	if prefix, found := os.lookup_env("PREFIX", context.temp_allocator); found && strings.contains(prefix, "com.termux") {
		return true
	}
	return os.is_directory("/data/data/com.termux/files/usr")
}

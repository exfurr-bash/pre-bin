#!/data/data/com.termux/files/usr/bin/env python3
"""Verify the TLS segment satisfies Android bionic (ARM64: align >= 64).

LLVM emits TLS with alignment 8 when Odin targets generic Linux; bionic
refuses to load such binaries ("TLS segment is underaligned"). build.sh
anchors the segment at 64 via contrib/termux/shim.c at link time, which
keeps every TP-relative relocation consistent.

Patching the binary afterwards is NOT safe (it corrupts the linker's
layout assumptions and crashes at runtime), so this script never writes:
it only fails the build with a clear message when the anchor is lost.

Usage: check_tls.py <elf-file>
Termux-only; never run on desktop builds.
"""
import struct
import sys


def main(path):
    with open(path, "rb") as f:
        d = f.read()
    if d[:4] != b"\x7fELF":
        print(f"check_tls: {path}: not an ELF file")
        return 1
    if d[4] != 2 or d[5] != 1:
        print("check_tls: only 64-bit little-endian ELF is supported")
        return 1
    phoff = struct.unpack_from("<Q", d, 0x20)[0]
    phentsz = struct.unpack_from("<H", d, 0x36)[0]
    phnum = struct.unpack_from("<H", d, 0x38)[0]

    found = False
    for i in range(phnum):
        o = phoff + i * phentsz
        ptype, flags, off, vaddr = struct.unpack_from("<IIQQ", d, o)
        filesz, memsz, align = struct.unpack_from("<QQQ", d, o + 32)
        if ptype != 7:  # PT_TLS
            continue
        found = True
        skew = (vaddr - off) % 64 if align else 0
        print(f"check_tls: PT_TLS p_align={align} skew={skew}")
        if align < 64 or skew != 0:
            print("check_tls: REJECTED by bionic (need align >= 64 and skew 0);")
            print("check_tls: the link-time anchor in contrib/termux/shim.c was lost?")
            return 1
    if not found:
        print("check_tls: no PT_TLS segment (fine: no thread-locals)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
